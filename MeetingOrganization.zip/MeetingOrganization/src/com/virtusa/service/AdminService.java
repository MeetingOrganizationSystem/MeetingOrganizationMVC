package com.virtusa.service;

import java.util.List;

import com.virtusa.entities.Rooms;
import com.virtusa.model.AdminModel;
import com.virtusa.model.RoomsModel;

public interface AdminService {
	public List<Rooms> viewAllInfo();
	public List<Rooms> addRoom();
	public List<Rooms> updateRoom();
	public List<Rooms> deleteRoom();
	 public void login();
}
