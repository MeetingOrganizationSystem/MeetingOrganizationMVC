package com.virtusa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.virtusa.dao.AdminDAO;
import com.virtusa.entities.Rooms;
import com.virtusa.helper.AdminFactory;
import com.virtusa.model.AdminModel;
import com.virtusa.model.RoomsModel;

public class AdminServiceImpl implements AdminService {
	private AdminDAO adminDAO;
	
	public AdminServiceImpl() {
		this.adminDAO=AdminFactory.createAdminDAO();
	}
	List<Rooms> roomModelList=new ArrayList<>();
     List<Rooms> roomsList=new ArrayList<>();
     Rooms rooms = new Rooms();
     Scanner sc = new Scanner(System.in);
     public void login()
     {
    	 String username="admin";
 		String password="admin@123";
 		System.out.println("Enter Admin UserName");
 		String name=sc.next();
 		System.out.println("Enter Admin Password");
 		String pwd=sc.next();
 		if(username.equals(name)&& password.equals(pwd))
 		{
 			System.out.println("Logged in successfully");
 		}
 		else
 		{
 			System.out.println("Invalid Details");
 			System.exit(0);
 		} 
     }
	@Override
	public List<Rooms> viewAllInfo() {
		// TODO Auto-generated method stub
        for(Rooms rooms:roomsList)
        {
        	System.out.println(rooms);
        }
		return roomsList;
        
	}

	@Override
	public List<Rooms> addRoom() {
		// TODO Auto-generated method stub
		System.out.println("Enter Floor Number.");
		rooms.setFloorNo(sc.nextInt());
		System.out.println("Enter Room Number");
		rooms.setRoomNo(sc.nextInt());
		System.out.println("Enter Room Type");
		rooms.setRoomType(sc.next());
		System.out.println("Enter Room Capacity");
		rooms.setCapacity(sc.nextInt());
		
		
		roomsList.add(rooms);
		
		for (Rooms room : roomsList) {
			System.out.println(room);
		}
		return roomModelList;
	}

	@Override
	public List<Rooms> updateRoom() {
		// TODO Auto-generated method stub
	    System.out.println("Enter roomNo to be updated");
	    int room=sc.nextInt();
	    {
	    	System.out.println("Enter floorNo");
	    	rooms.setFloorNo(sc.nextInt());
			System.out.println("Enter Room Number");
			rooms.setRoomNo(sc.nextInt());
			System.out.println("Enter Room Type");
			rooms.setRoomType(sc.next());
			System.out.println("Enter Room Capacity");
			rooms.setCapacity(sc.nextInt());
			
			
			roomsList.add(rooms);
	    }
		return roomModelList;
	    
	}

	@Override
	public List<Rooms> deleteRoom() {
		// TODO Auto-generated method stub
		System.out.println("Enter roomNo to be deleted");
	    int room=sc.nextInt();
	    {
	    	System.out.println("Enter floorNo");
	    	rooms.setFloorNo(sc.nextInt());
			System.out.println("Enter Room Number");
			rooms.setRoomNo(sc.nextInt());
			System.out.println("Enter Room Type");
			rooms.setRoomType(sc.next());
			System.out.println("Enter Room Capacity");
			rooms.setCapacity(sc.nextInt());
			
			
			roomsList.remove(rooms);
	    }
		return roomModelList;    
	}

}
