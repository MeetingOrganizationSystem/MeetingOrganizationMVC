package com.virtusa.controller;

import java.util.List;

import com.virtusa.entities.Rooms;
import com.virtusa.helper.AdminFactory;
import com.virtusa.model.AdminModel;
import com.virtusa.service.AdminService;
import com.virtusa.view.MainView;

public class AdminController {
	private AdminService adminService;
	MainView adminView=new MainView();
	public AdminController() {
		this.adminService=AdminFactory.createAdminService();
	}
		public void viewAllInfo() 
		{
			List<Rooms> models=adminService.viewAllInfo();
			adminView.viewAllInfo();
	    }
	    public void addRoom()
	    {
	    	List<Rooms> models=adminService.addRoom();
	        adminView.addRoom();
	    }
	    public void updateRoom()
	    {
	    	List<Rooms> models=adminService.updateRoom();
	    	adminView.updateRoom();
	    }
	    public void deleteRoom()
	    {
	    	List<Rooms> models=adminService.deleteRoom();
	        adminView.deleteRoom();
	    }
}