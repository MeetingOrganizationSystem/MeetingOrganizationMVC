package com.virtusa.view;

import java.sql.SQLException;
import java.util.Scanner;

import com.virtusa.controller.AdminController;

import com.virtusa.dao.AdminDAO;
import com.virtusa.dao.AdminDAOImpl;
import com.virtusa.service.AdminService;
import com.virtusa.service.AdminServiceImpl;

public class MainView {
	static AdminService adminService=new AdminServiceImpl();
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		AdminDAO adminDAO=new AdminDAOImpl();
		AdminController adminController=new AdminController();
	   adminService.login();
	   while(true)
	   {
		   System.out.println("Welcome Admin");
			System.out.println("1.Add Room\n 2.Update Room\n 3.Delete Room\n 4.View All Information\n 5.Exit");	
			int choice=scanner.nextInt();
			switch(choice){
			case 1: adminController.addRoom();
		    break;
			
			case 2: adminController.updateRoom();
		    break;
				
			case 3: adminController.deleteRoom();
	    
			break;
			case 4: adminController.viewAllInfo();
			break;
	    }
	  }
	}
	public void viewAllInfo()
	{
		
	}
	public void addRoom()
	{
		
	}
	public void updateRoom()
	{
		
	}
	public void deleteRoom()
	{
		
	}
}
