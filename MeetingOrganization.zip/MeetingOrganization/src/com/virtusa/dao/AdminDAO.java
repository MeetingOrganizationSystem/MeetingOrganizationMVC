package com.virtusa.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.Rooms;

public interface AdminDAO {
   public void viewAllInfo() throws SQLException; 
   public boolean addRoom() throws SQLException, ClassNotFoundException;
   public void updateRoom() throws SQLException;
   public void deleteRoom() throws SQLException;
   
   
}
