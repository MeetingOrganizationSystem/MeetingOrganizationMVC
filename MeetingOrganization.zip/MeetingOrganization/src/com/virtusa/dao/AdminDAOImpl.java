package com.virtusa.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.virtusa.entities.Rooms;

public class AdminDAOImpl implements AdminDAO {
    @Override
	public void viewAllInfo() throws SQLException{
    	Rooms rooms=new Rooms();
		 Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			PreparedStatement preparedStatement=connection.prepareStatement("select * from test.roomInfo");
	         ResultSet resultSet=preparedStatement.executeQuery();
	         connection.close();
	         System.out.println(rooms);
	         return ;    
	        
	}
	@Override
	public boolean addRoom() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		   Rooms rooms=new Rooms();
		    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
			PreparedStatement preparedStatement=connection.prepareStatement("insert into test.roomInfo values(?,?,?,?)");
			preparedStatement.setInt(1,rooms.getFloorNo());
			preparedStatement.setInt(2,rooms.getRoomNo());
			preparedStatement.setString(3, rooms.getRoomType());
			preparedStatement.setInt(4,rooms.getCapacity());
			int rows=preparedStatement.executeUpdate();
			connection.close();
			if(rows>0) {
				return true;
			}
			else
				return false;
			
	}

	@Override
	public void updateRoom() throws SQLException {
		Rooms rooms=new Rooms();
		// TODO Auto-generated method stub
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
		PreparedStatement preparedStatement=connection.prepareStatement("update test.roomInfo set floorNo=?,roomNo=?,roomType=?,capacity=? where roomNo=?");
		preparedStatement.setInt(1,rooms.getFloorNo());
		preparedStatement.setInt(2,rooms.getRoomNo());
		preparedStatement.setString(3, rooms.getRoomType());
		preparedStatement.setInt(4,rooms.getCapacity());
		preparedStatement.setInt(2, 2);
		preparedStatement.executeUpdate();
		System.out.println("database updated succesfully");
		connection.close();
	}

	@Override
	public void deleteRoom() throws SQLException {
		Rooms rooms=new Rooms();
		// TODO Auto-generated method stub
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=root");
		PreparedStatement preparedStatement=connection.prepareStatement("delete from test.roomInfo  values(?,?,?,?) where roomNo=?");
		preparedStatement.setInt(1,rooms.getRoomNo());
		preparedStatement.executeUpdate();
		System.out.println("database deleted succesfully");
		connection.close();
	}

}
